package org.pond.figura_optimize;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import org.pond.figura_optimize.config.FiguraOptimizeConfig;

@Environment(EnvType.CLIENT)
public class FiguraOptimizeClient implements ClientModInitializer {
   private static class_304 toggleDistanceLODKey;

   public void onInitializeClient() {
      FiguraOptimizeConfig.load();
      toggleDistanceLODKey = KeyBindingHelper.registerKeyBinding(new class_304("key.figura_optimize.toggle_distance_lod", 75, "key.categories.figura_optimize"));
      ClientTickEvents.END_CLIENT_TICK.register((ClientTickEvents.EndTick)(client) -> {
         ++FiguraOptimizeConfig.tickCounter;

         boolean changed;
         for(changed = false; toggleDistanceLODKey.method_1436(); changed = true) {
            FiguraOptimizeConfig.distanceLODEnabled = !FiguraOptimizeConfig.distanceLODEnabled;
         }

         if (changed) {
            FiguraOptimizeConfig.save();
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 != null) {
               mc.field_1724.method_7353(class_2561.method_43470("Distance LOD: " + (FiguraOptimizeConfig.distanceLODEnabled ? "ON" : "OFF")), true);
            }
         }

         if (client.field_1687 != null && client.field_1687 != FiguraOptimizeConfig.lastWorld) {
            FiguraOptimizeConfig.clearRenderMap();
            FiguraOptimizeConfig.lastWorld = client.field_1687;
         }

      });
      ClientPlayConnectionEvents.DISCONNECT.register((ClientPlayConnectionEvents.Disconnect)(handler, client) -> {
         FiguraOptimizeConfig.clearRenderMap();
         FiguraOptimizeConfig.lastWorld = null;
         FiguraOptimizeConfig.tickCounter = 0L;
      });
   }

   public static void saveConfig() {
      FiguraOptimizeConfig.save();
   }
}
