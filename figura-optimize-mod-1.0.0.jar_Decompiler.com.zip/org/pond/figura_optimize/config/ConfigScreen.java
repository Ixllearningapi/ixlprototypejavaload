package org.pond.figura_optimize.config;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import org.pond.figura_optimize.FiguraOptimizeClient;

@Environment(EnvType.CLIENT)
public class ConfigScreen {
   public static class_437 getScreen(class_437 parent) {
      ConfigBuilder builder = ConfigBuilder.create().setParentScreen(parent).setTitle(class_2561.method_43470("Figura Optimize"));
      ConfigCategory distanceLodCategory = builder.getOrCreateCategory(class_2561.method_43470("Distance LOD"));
      ConfigCategory throttleCategory = builder.getOrCreateCategory(class_2561.method_43470("Render Throttle"));
      ConfigEntryBuilder entryBuilder = builder.entryBuilder();
      distanceLodCategory.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Enable Distance LOD"), FiguraOptimizeConfig.distanceLODEnabled).setDefaultValue(false).setSaveConsumer((value) -> FiguraOptimizeConfig.distanceLODEnabled = value).build());
      distanceLodCategory.addEntry(entryBuilder.startIntSlider(class_2561.method_43470("Distance Range"), FiguraOptimizeConfig.distanceLODRange, 0, 128).setDefaultValue(32).setSaveConsumer((value) -> FiguraOptimizeConfig.distanceLODRange = value).build());
      throttleCategory.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Enable Render Throttle"), FiguraOptimizeConfig.renderThrottleEnabled).setDefaultValue(true).setSaveConsumer((value) -> FiguraOptimizeConfig.renderThrottleEnabled = value).build());
      builder.setSavingRunnable(() -> FiguraOptimizeClient.saveConfig());
      return builder.build();
   }
}
