package org.pond.figura_optimize.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1937;

@Environment(EnvType.CLIENT)
public class FiguraOptimizeConfig {
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "figura_optimize.json");
   public static boolean distanceLODEnabled = false;
   public static int distanceLODRange = 32;
   public static boolean renderThrottleEnabled = true;
   public static final Map<UUID, Long> lastRenderMap = new ConcurrentHashMap();
   public static long tickCounter = 0L;
   public static class_1937 lastWorld = null;

   public static void load() {
      if (!CONFIG_FILE.exists()) {
         save();
      } else {
         try {
            FileReader reader = new FileReader(CONFIG_FILE);

            try {
               JsonObject json = (JsonObject)GSON.fromJson(reader, JsonObject.class);
               if (json != null) {
                  if (json.has("distanceLODEnabled")) {
                     distanceLODEnabled = json.get("distanceLODEnabled").getAsBoolean();
                  }

                  if (json.has("distanceLODRange")) {
                     distanceLODRange = json.get("distanceLODRange").getAsInt();
                  }

                  if (json.has("renderThrottleEnabled")) {
                     renderThrottleEnabled = json.get("renderThrottleEnabled").getAsBoolean();
                  }
               }
            } catch (Throwable var4) {
               try {
                  reader.close();
               } catch (Throwable var3) {
                  var4.addSuppressed(var3);
               }

               throw var4;
            }

            reader.close();
         } catch (IOException e) {
            e.printStackTrace();
         }

      }
   }

   public static void save() {
      JsonObject json = new JsonObject();
      json.addProperty("distanceLODEnabled", distanceLODEnabled);
      json.addProperty("distanceLODRange", distanceLODRange);
      json.addProperty("renderThrottleEnabled", renderThrottleEnabled);
      CompletableFuture.runAsync(() -> {
         try {
            FileWriter writer = new FileWriter(CONFIG_FILE);

            try {
               GSON.toJson(json, writer);
            } catch (Throwable var5) {
               try {
                  writer.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }

               throw var5;
            }

            writer.close();
         } catch (IOException e) {
            e.printStackTrace();
         }

      });
   }

   public static void clearRenderMap() {
      lastRenderMap.clear();
   }
}
