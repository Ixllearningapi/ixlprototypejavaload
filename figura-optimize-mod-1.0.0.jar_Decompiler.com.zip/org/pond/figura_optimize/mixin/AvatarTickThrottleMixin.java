package org.pond.figura_optimize.mixin;

import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.figuramc.figura.avatar.Avatar;
import org.pond.figura_optimize.config.FiguraOptimizeConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(
   value = {Avatar.class},
   remap = false
)
public class AvatarTickThrottleMixin {
   @Shadow
   public UUID owner;

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")},
      cancellable = true,
      remap = false
   )
   private void figuraOptimize$throttleTick(CallbackInfo ci) {
      if (this.owner != null) {
         if (!FiguraOptimizeConfig.distanceLODEnabled) {
            if (FiguraOptimizeConfig.renderThrottleEnabled) {
               class_310 mc = class_310.method_1551();
               if (mc.field_1724 == null || mc.field_1687 == null) {
                  return;
               }

               class_1657 entity = mc.field_1687.method_18470(this.owner);
               if (entity == null) {
                  return;
               }

               if (entity.method_5667().equals(mc.field_1724.method_5667())) {
                  return;
               }

               double distSq = mc.field_1724.method_5858(entity);
               int intervalTicks = this.getThrottleIntervalTicks(distSq);
               long currentTick = FiguraOptimizeConfig.tickCounter;
               Long lastTick = (Long)FiguraOptimizeConfig.lastRenderMap.get(entity.method_5667());
               long lastTime = lastTick != null ? lastTick : 0L;
               if (currentTick - lastTime < (long)intervalTicks) {
                  ci.cancel();
                  return;
               }

               FiguraOptimizeConfig.lastRenderMap.put(entity.method_5667(), currentTick);
            }

         }
      }
   }

   @Unique
   private int getThrottleIntervalTicks(double distSq) {
      if (distSq <= (double)256.0F) {
         return 1;
      } else {
         return distSq <= (double)1024.0F ? 2 : 4;
      }
   }
}
