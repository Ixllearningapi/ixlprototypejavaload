package org.pond.figura_optimize.mixin;

import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.figuramc.figura.avatar.Avatar;
import org.figuramc.figura.avatar.AvatarManager;
import org.pond.figura_optimize.config.FiguraOptimizeConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(
   value = {AvatarManager.class},
   remap = false
)
public class DistanceLODMixin {
   @Inject(
      method = {"getAvatar"},
      at = {@At("HEAD")},
      cancellable = true,
      remap = false
   )
   private static void figuraOptimize$getAvatar(class_1297 entity, CallbackInfoReturnable<Avatar> cir) {
      if (shouldHideFigura(entity)) {
         cir.setReturnValue((Object)null);
      }

   }

   @Inject(
      method = {"getAvatarForEntity"},
      at = {@At("HEAD")},
      cancellable = true,
      remap = false
   )
   private static void figuraOptimize$getAvatarForEntity(class_1297 entity, CallbackInfoReturnable<Avatar> cir) {
      if (shouldHideFigura(entity)) {
         cir.setReturnValue((Object)null);
      }

   }

   @Inject(
      method = {"getAvatarForPlayer"},
      at = {@At("HEAD")},
      cancellable = true,
      remap = false
   )
   private static void figuraOptimize$getAvatarForPlayer(UUID playerUuid, CallbackInfoReturnable<Avatar> cir) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1687 != null) {
         class_1657 player = mc.field_1687.method_18470(playerUuid);
         if (shouldHideFigura(player)) {
            cir.setReturnValue((Object)null);
         }
      }

   }

   private static boolean shouldHideFigura(class_1297 entity) {
      if (entity == null) {
         return false;
      } else {
         class_310 mc = class_310.method_1551();
         if (mc.field_1724 == null) {
            return false;
         } else {
            if (FiguraOptimizeConfig.distanceLODEnabled && !entity.method_5667().equals(mc.field_1724.method_5667())) {
               int maxDist = FiguraOptimizeConfig.distanceLODRange;
               if (maxDist > 0) {
                  double distSq = mc.field_1724.method_5858(entity);
                  if (distSq > (double)(maxDist * maxDist)) {
                     return true;
                  }
               }
            }

            return false;
         }
      }
   }
}
